
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'huytq57',
  applicationName: 'tungts4-todoapp',
  appUid: 'wqS27sj6bGgSwvf3nT',
  orgUid: 'ca5b6884-5a90-4eff-af01-fa29e5054210',
  deploymentUid: '72590952-7dfb-4cba-9dde-2c265a552b63',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-Auth', timeout: 6 };

try {
  const userHandler = require('./src/lambda/auth/auth0Authorizer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}